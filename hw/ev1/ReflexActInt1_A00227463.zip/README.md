# E1: Actividad Integradora 1 
## Análisis de Algoritmos Avanzados 

Andrés Daniel Martínez - A00227463

### Análisis (Posibles soluciones)
- Sliding Window 
- KMP (Knuth Morris Prath) Pattern Searching Algorithm 
